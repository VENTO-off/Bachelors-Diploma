package nuzp.yuliy_gorichenko.openhab_helper;

import java.util.Scanner;

public class Emulator {
    private static double amperage;
    private static double temperature;

    //TODO REMOVE
    public static void init() {
        amperage = -1;
        temperature = -1;

        Thread t = new Thread(() -> {
            Scanner in = new Scanner(System.in);
            System.out.println("Waiting command...");

            while (in.hasNext()) {
                String cmd = in.next();
                if (cmd.contains("=")) {
                    String[] args = cmd.split("=");

                    try {
                        double value = Double.parseDouble(args[1]);
                        if (value <= 0) value = -1;

                        if (args[0].equalsIgnoreCase("a")) {
                            amperage = value;
                        } else if (args[0].equalsIgnoreCase("t")) {
                            temperature = value;
                        }

                        System.out.println("OK.");
                    } catch (Exception e) {
                        System.out.println("Error!");
                    }
                }
            }

        });

        t.start();
    }

    public static double getAmperage() {
        return amperage;
    }

    public static double getTemperature() {
        return temperature;
    }
}
