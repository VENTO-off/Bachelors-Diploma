package nuzp.yuliy_gorichenko.openhab_helper.exceptions;

public class DataBaseConnectionException extends Exception {
    /**
     * Constructor
     */
    public DataBaseConnectionException() {
        super("error.connection.database");
    }
}
