package nuzp.yuliy_gorichenko.openhab_helper.exceptions;

public class OpenHabException extends Exception {
    /**
     * Constructor
     */
    public OpenHabException() {
        super("error.openhab");
    }
}
