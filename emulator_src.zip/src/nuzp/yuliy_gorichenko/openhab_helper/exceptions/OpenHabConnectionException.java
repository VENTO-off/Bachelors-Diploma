package nuzp.yuliy_gorichenko.openhab_helper.exceptions;

public class OpenHabConnectionException extends Exception {
    /**
     * Constructor
     */
    public OpenHabConnectionException() {
        super("error.connection.openhab");
    }
}
