package nuzp.yuliy_gorichenko.openhab_helper.exceptions;

public class DataBaseException extends Exception {
    /**
     * Constructor
     */
    public DataBaseException() {
        super("error.database");
    }
}
